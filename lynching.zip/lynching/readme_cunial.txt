notes:

1. the fundamental unit of a story is the "semantic triplet", which consists of one or more subjects, one or more actions, and one or more objects, each with corresponding features. semantic triplets are themselves organized into a short hierarchy of concepts (macro event->event->semantic triplet). due to legacy reasons, the full dataset is represented here as three separate matrices, which need to be recombined into one with the following sql join:

subject INNER JOIN action INNER JOIN object on
subject.[id semantic triplet]=action.[id semantic triplet]
and action.[id semantic triplet]=object.[id semantic triplet]


2. when formatting the matrix for your data mining algorithms, please discard the following fields:

from <./subject.txt>:

id semantic triplet
identifier semantic triplet
id participant-s
id individual
id collective actor

from <./object.txt>:

id semantic triplet
identifier semantic triplet
id participant-o
id individual
id collective actor

from <./action.txt>:

id semantic triplet
identifier semantic triplet
id process
id simple process
id complex process
.id


3. the following, human-generated fields try to aggregate multiple values from other fields into more general categories. the fields suffixed by "colin" use an eponymous, alternative aggregation criterion. please use either all the aggregate fields suffixed by "colin", or all aggregate fields that are not suffixed by "colin", but do not mix the two.

from <./subject.txt>:

actor aggregate code
actor aggregate code'
actor aggregate (individual) colin
actor aggregate (collective) colin
actor aggregate (organization) colin

from <./object.txt>:
actor aggregate code
actor aggregate code'
actor aggregate (individual) colin
actor aggregate (collective) colin
actor aggregate (organization) colin

from <./action.txt>:
action aggregate code
action aggregate code'
action aggregate code''
action aggregate (simple process) colin
action aggregate (simple process) colin'
action aggregate (simple process) colin''
action aggregate (complex process) colin


4. some rows in <./subject.txt>, <./action.txt> and <./object.txt> have one of the following structures:

id macro event|||||||||||||||||||||||||||||||||||
id macro event|sequence event|id event||||||||||||||||||||||||||

please discard such rows.